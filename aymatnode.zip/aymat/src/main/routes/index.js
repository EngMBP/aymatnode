const aymatRouter = require('./aymatRouter');

module.exports = {
  aymatRouter
};